import json
import os

LOCAL_DATA_FILE = "user_data.json"

def get_saved_user_id():
    if os.path.exists(LOCAL_DATA_FILE):
        try:
            with open(LOCAL_DATA_FILE, 'r') as f:
                data = json.load(f)
                return data.get('user_id')
        except:
            return None
    return None

def save_user_id(user_id):
    data = {"user_id": user_id}
    with open(LOCAL_DATA_FILE, 'w') as f:
        json.dump(data, f)

def clear_user_id():
    if os.path.exists(LOCAL_DATA_FILE):
        os.remove(LOCAL_DATA_FILE)