import customtkinter as ctk
from customtkinter import CTkInputDialog

def show_registration_modal(app, db):
    dialog = CTkInputDialog(
        text="Welcome! Please enter your Discord User ID to register:",
        title="First-Time Setup"
    )
    
    dialog.geometry(f"+{app.winfo_x()+100}+{app.winfo_y()+100}")
    dialog.lift()
    dialog.focus_force()
    
    user_input = dialog.get_input()

    if user_input is None:
        app.quit()
        return None

    user_input = user_input.strip()

    if not user_input.isdigit():
        error_label = ctk.CTkLabel(app, text="Error: User ID must be a number.", text_color="red")
        error_label.pack(padx=20, pady=20)
        app.after(3000, app.quit)
        return None

    if db.user_exists(user_input):
        return user_input
    else:
        db.create_user(user_input, f"User_{user_input}") 
        return user_input