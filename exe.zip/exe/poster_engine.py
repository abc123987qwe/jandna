import discord
import asyncio
import time
import aiohttp
import datetime
from discord.ext import commands
from database import MongoDB

class PosterEngine:
    def __init__(self, db: MongoDB, user_id: str):
        self.db = db
        self.user_id = user_id
        self.config = self.db.get_config(user_id) or {}
        self.status = "Stopped"
        self.is_running = False
        self.start_time = None
        self.client = None
        self.task = None

    def update_config(self):
        self.config = self.db.get_config(self.user_id) or {}

    async def send_to_webhook(self, channel_id, status, message=None):
        if not self.config.get("webhook_url"):
            return

        current_time = datetime.datetime.now(datetime.timezone.utc)
        formatted_timestamp = current_time.isoformat()
        
        elapsed_time = int(time.time() - self.start_time) if self.start_time else 0
        hours = elapsed_time // 3600
        minutes = (elapsed_time % 3600) // 60
        seconds = elapsed_time % 60

        if hours > 0:
            uptime_formatted = f"{hours}h {minutes}m {seconds}s"
        elif minutes > 0:
            uptime_formatted = f"{minutes}m {seconds}s"
        else:
            uptime_formatted = f"{seconds}s"

        description = f"**User**: <@{self.user_id}>\n**Channel**: <#{channel_id}>\n**Delay**: {self.config.get('delay_in_minutes', 1)}min\n**Uptime**: {uptime_formatted}\n**Status**: {status}"
        if message:
            description += f"\n**Message**: {message}"

        webhook_data = {
            "embeds": [
                {
                    "title": "📌 Auto Post Logs 📌",
                    "description": description,
                    "color": 5814783 if "✅" in status else 15158332 if "❌" in status else 15844367,
                    "footer": {"text": "Auto Post by Duxii & Screamy"},
                    "timestamp": formatted_timestamp,
                    "thumbnail": {
                        "url": "https://media.discordapp.net/attachments/1297259902280142889/1303381989507858523/a_0dddc192f7f6ae93750c68f3526cc6d4.gif"
                    }
                }
            ]
        }

        try:
            async with aiohttp.ClientSession() as session:
                async with session.post(self.config["webhook_url"], json=webhook_data) as response:
                    if response.status != 204:
                        print(f"Webhook error: {response.status}")
        except Exception as e:
            print(f"Webhook failed: {e}")

    async def send_message(self, channel_id, message_content, attachments):
        try:
            channel = self.client.get_channel(int(channel_id))
            if channel is None:
                error_msg = f"Channel {channel_id} not found"
                print(error_msg)
                await self.send_to_webhook(channel_id, "Error ❌", error_msg)
                self.db.add_log(self.user_id, {
                    "type": "error",
                    "channel_id": channel_id,
                    "message": error_msg
                })
                return False

            files = []
            for attachment in attachments:
                if attachment and isinstance(attachment, str) and attachment.strip():
                    try:
                        files.append(discord.File(attachment.strip()))
                    except Exception as e:
                        error_msg = f"Failed to load attachment: {e}"
                        print(error_msg)
                        await self.send_to_webhook(channel_id, "Error ❌", error_msg)
            
            await channel.send(content=message_content, files=files)
            success_msg = f"Message sent to channel {channel_id}"
            print(success_msg)
            await self.send_to_webhook(channel_id, "Success ✅", success_msg)
            self.db.add_log(self.user_id, {
                "type": "success",
                "channel_id": channel_id,
                "message": success_msg
            })
            return True
        except Exception as e:
            error_msg = f"Failed to send message: {e}"
            print(error_msg)
            await self.send_to_webhook(channel_id, "Error ❌", error_msg)
            self.db.add_log(self.user_id, {
                "type": "error",
                "channel_id": channel_id,
                "message": error_msg
            })
            return False

    async def send_messages_loop(self):
        self.is_running = True
        self.status = "Running ✅"
        self.start_time = time.time()
        
        print("Poster started successfully!")
        self.db.add_log(self.user_id, {
            "type": "info",
            "message": "Poster engine started"
        })
        
        while self.is_running:
            self.update_config()
            
            if not self.config.get("channels"):
                print("No channels configured. Waiting...")
                await asyncio.sleep(10)
                continue
            
            for channel_info in self.config["channels"]:
                if not self.is_running:
                    break
                    
                channel_id = channel_info.get("id", "")
                message = channel_info.get("message", "")
                attachments = channel_info.get("attachments", [])
                
                if channel_id and message:
                    await self.send_message(channel_id, message, attachments)
                
                for _ in range(30):
                    if not self.is_running:
                        break
                    await asyncio.sleep(1)
            
            delay_seconds = self.config.get("delay_in_minutes", 1) * 60
            for _ in range(delay_seconds):
                if not self.is_running:
                    break
                await asyncio.sleep(1)
        
        self.status = "Stopped 🛑"
        print("Poster stopped.")
        self.db.add_log(self.user_id, {
            "type": "info",
            "message": "Poster engine stopped"
        })

    def start(self, loop):
        if not self.config.get("token"):
            print("Error: No Discord token configured")
            self.status = "Error: No Token ❌"
            self.db.add_log(self.user_id, {
                "type": "error",
                "message": "Failed to start: No Discord token configured"
            })
            return False
            
        try:
            self.client = commands.Bot(
                command_prefix='!',
                intents=discord.Intents.all(),
                self_bot=True
            )
            self.task = loop.create_task(self.send_messages_loop())
            loop.create_task(self.client.start(self.config["token"], bot=False))
            return True
        except Exception as e:
            error_msg = f"Failed to start poster: {e}"
            print(error_msg)
            self.status = f"Error: {str(e)} ❌"
            self.db.add_log(self.user_id, {
                "type": "error",
                "message": error_msg
            })
            return False

    def stop(self):
        self.is_running = False
        if self.client:
            asyncio.create_task(self.client.close())
        if self.task:
            self.task.cancel()
        print("Stopping poster...")