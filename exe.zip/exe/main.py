import customtkinter as ctk
import asyncio
import threading
import subprocess
import sys
import os
from database import MongoDB
from local_storage import get_saved_user_id, save_user_id, clear_user_id
from login_modal import show_registration_modal
from dashboard_frame import DashboardFrame

# REPLACE WITH YOUR MONGODB URI
DB_URI = "mongodb+srv://username:password@cluster.mongodb.net/"

class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Auto Poster Pro")
        self.geometry("400x200")
        
        self.db = MongoDB(DB_URI)
        self.current_user_id = None
        self.poster_engine = None
        self.loop = asyncio.new_event_loop()
        
        ctk.set_appearance_mode("Dark")
        ctk.set_default_color_theme("blue")
        
        self.center_window()
        self.check_existing_login()

    def center_window(self):
        self.update_idletasks()
        width = self.winfo_width()
        height = self.winfo_height()
        x = (self.winfo_screenwidth() // 2) - (width // 2)
        y = (self.winfo_screenheight() // 2) - (height // 2)
        self.geometry(f'{width}x{height}+{x}+{y}')

    def check_existing_login(self):
        saved_user_id = get_saved_user_id()
        
        if saved_user_id:
            self.current_user_id = saved_user_id
            self.show_dashboard()
        else:
            self.current_user_id = show_registration_modal(self, self.db)
            if self.current_user_id:
                save_user_id(self.current_user_id)
                self.show_dashboard()
            else:
                self.quit()

    def show_dashboard(self):
        for widget in self.winfo_children():
            widget.destroy()
        
        self.geometry("1000x700")
        self.center_window()
        
        from poster_engine import PosterEngine
        self.poster_engine = PosterEngine(self.db, self.current_user_id)
        
        self.dashboard = DashboardFrame(self, self.db, self.poster_engine, self.loop)
        self.dashboard.pack(fill="both", expand=True)
        
        self.start_async_loop()

    def start_async_loop(self):
        def run_loop():
            asyncio.set_event_loop(self.loop)
            self.loop.run_forever()

        thread = threading.Thread(target=run_loop, daemon=True)
        thread.start()

    def logout(self):
        if self.poster_engine:
            self.poster_engine.stop()
        self.loop.call_soon_threadsafe(self.loop.stop)
        clear_user_id()
        self.destroy()
        
        # Restart the application
        python = sys.executable
        subprocess.Popen([python, __file__])
        sys.exit()

    def on_closing(self):
        if self.poster_engine:
            self.poster_engine.stop()
        self.loop.call_soon_threadsafe(self.loop.stop)
        self.destroy()

if __name__ == "__main__":
    app = App()
    app.protocol("WM_DELETE_WINDOW", app.on_closing)
    app.mainloop()