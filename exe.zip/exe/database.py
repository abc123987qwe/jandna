from pymongo import MongoClient
import datetime
from typing import Dict, Any, List, Optional

class MongoDB:
    def __init__(self, uri: str, db_name: str = "auto_poster_db"):
        self.client = MongoClient(uri)
        self.db = self.client[db_name]
        self.config_collection = self.db["configs"]
        self.users_collection = self.db["users"]
        self.logs_collection = self.db["logs"]

    def user_exists(self, user_id: int) -> bool:
        return self.users_collection.find_one({"discord_id": str(user_id)}) is not None

    def create_user(self, user_id: int, username: str) -> Dict[str, Any]:
        user_doc = {
            "discord_id": str(user_id),
            "username": username,
            "created_at": datetime.datetime.utcnow()
        }
        self.users_collection.insert_one(user_doc)
        
        default_config = {
            "user_id": str(user_id),
            "token": "",
            "channels": [],
            "delay_in_minutes": 1,
            "webhook_url": ""
        }
        self.config_collection.insert_one(default_config)
        return default_config

    def get_config(self, user_id: int) -> Optional[Dict[str, Any]]:
        config = self.config_collection.find_one({"user_id": str(user_id)})
        if config:
            config.pop('_id', None)
        return config

    def update_config(self, user_id: int, update_data: Dict[str, Any]) -> bool:
        result = self.config_collection.update_one(
            {"user_id": str(user_id)},
            {"$set": update_data},
            upsert=True
        )
        return result.modified_count > 0

    def update_config_field(self, user_id: int, field: str, value: Any) -> bool:
        return self.update_config(user_id, {field: value})

    def add_channel(self, user_id: int, channel_data: Dict[str, Any]) -> bool:
        result = self.config_collection.update_one(
            {"user_id": str(user_id)},
            {"$push": {"channels": channel_data}}
        )
        return result.modified_count > 0

    def update_channel(self, user_id: int, channel_id: str, update_data: Dict[str, Any]) -> bool:
        result = self.config_collection.update_one(
            {"user_id": str(user_id), "channels.id": channel_id},
            {"$set": {"channels.$": update_data}}
        )
        return result.modified_count > 0

    def remove_channel(self, user_id: int, channel_id: str) -> bool:
        result = self.config_collection.update_one(
            {"user_id": str(user_id)},
            {"$pull": {"channels": {"id": channel_id}}}
        )
        return result.modified_count > 0

    def add_log(self, user_id: int, log_data: Dict[str, Any]):
        log_data.update({
            "user_id": str(user_id),
            "timestamp": datetime.datetime.utcnow()
        })
        return self.logs_collection.insert_one(log_data)

    def get_logs(self, user_id: int, limit: int = 100) -> List[Dict[str, Any]]:
        logs = self.logs_collection.find({"user_id": str(user_id)}).sort("timestamp", -1).limit(limit)
        return [{k: v for k, v in log.items() if k != '_id'} for log in logs]

    def clear_logs(self, user_id: int) -> bool:
        result = self.logs_collection.delete_many({"user_id": str(user_id)})
        return result.deleted_count > 0