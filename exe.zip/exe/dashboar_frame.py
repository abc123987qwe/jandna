import customtkinter as ctk
import threading
import time
import os
import tkinter as tk
from tkinterdnd2 import DND_FILES
from tkinter import filedialog

class DashboardFrame(ctk.CTkFrame):
    def __init__(self, parent, db, poster_engine, loop):
        super().__init__(parent)
        self.db = db
        self.engine = poster_engine
        self.loop = loop
        self.is_running = False
        self.current_channel = None
        self.attachments = []
        self.start_time = None

        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self.setup_header()
        
        self.tabview = ctk.CTkTabview(self)
        self.tabview.grid(row=1, column=0, sticky="nsew", padx=10, pady=(0, 10))
        
        self.tabview.add("Channels")
        self.tabview.add("Settings")
        self.tabview.add("Logs")

        for tab in ["Channels", "Settings", "Logs"]:
            self.tabview.tab(tab).grid_columnconfigure(0, weight=1)
            self.tabview.tab(tab).grid_rowconfigure(0, weight=1)

        self.setup_channels_tab()
        self.setup_settings_tab()
        self.setup_logs_tab()

        self.update_status()

    def setup_header(self):
        header = ctk.CTkFrame(self, height=60)
        header.grid(row=0, column=0, sticky="ew", padx=10, pady=10)
        header.grid_columnconfigure(1, weight=1)

        title_frame = ctk.CTkFrame(header, fg_color="transparent")
        title_frame.grid(row=0, column=0, padx=10, pady=10, sticky="w")
        
        title = ctk.CTkLabel(title_frame, text="🚀 Auto Poster Pro", font=("", 24, "bold"))
        title.pack(side="left", padx=(0, 10))

        self.status_var = ctk.StringVar(value=f"Status: {self.engine.status}")
        status_label = ctk.CTkLabel(header, textvariable=self.status_var, 
                                   font=("", 14), text_color="lightgreen")
        status_label.grid(row=0, column=1, padx=10, pady=10)

        self.uptime_var = ctk.StringVar(value="Uptime: 00:00:00")
        uptime_label = ctk.CTkLabel(header, textvariable=self.uptime_var, 
                                   font=("", 12), text_color="lightblue")
        uptime_label.grid(row=0, column=2, padx=10, pady=10)

        button_frame = ctk.CTkFrame(header, fg_color="transparent")
        button_frame.grid(row=0, column=3, padx=10, pady=10)

        self.start_btn = ctk.CTkButton(button_frame, text="▶ Start", 
                                     command=self.start_poster, width=80,
                                     fg_color="green", hover_color="darkgreen")
        self.start_btn.pack(side="left", padx=5)

        self.stop_btn = ctk.CTkButton(button_frame, text="⏹ Stop", 
                                    command=self.stop_poster, width=80,
                                    state="disabled", 
                                    fg_color="#d9534f", hover_color="#c9302c")
        self.stop_btn.pack(side="left", padx=5)

        user_frame = ctk.CTkFrame(header, fg_color="transparent")
        user_frame.grid(row=0, column=4, padx=10, pady=10)
        
        user_label = ctk.CTkLabel(user_frame, text=f"User: {self.engine.user_id}", 
                                 font=("", 12))
        user_label.pack(side="left", padx=(0, 10))
        
        logout_btn = ctk.CTkButton(user_frame, text="Logout", 
                                  command=self.master.logout, width=60)
        logout_btn.pack(side="left")

    def setup_channels_tab(self):
        frame = self.tabview.tab("Channels")
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_rowconfigure(1, weight=1)

        left_panel = ctk.CTkFrame(frame, width=200)
        left_panel.grid(row=0, column=0, rowspan=2, sticky="nsw", padx=(0, 10), pady=10)
        left_panel.grid_propagate(False)

        channel_header = ctk.CTkFrame(left_panel, height=40)
        channel_header.pack(fill="x", pady=(0, 10))
        
        add_btn = ctk.CTkButton(channel_header, text="+ Add Channel", 
                               command=self.add_channel, width=120)
        add_btn.pack(pady=10)

        self.channel_listbox = tk.Listbox(left_panel, bg="#2b2b2b", fg="white", 
                                        selectbackground="#3b8ed0", font=("", 12))
        self.channel_listbox.pack(fill="both", expand=True, padx=10, pady=10)
        self.channel_listbox.bind('<<ListboxSelect>>', self.on_channel_select)

        right_panel = ctk.CTkFrame(frame)
        right_panel.grid(row=0, column=1, sticky="nsew", padx=10, pady=10)
        right_panel.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(right_panel, text="Channel ID:", font=("", 14, "bold")).grid(
            row=0, column=0, sticky="w", pady=(0, 5))
        self.channel_id_var = ctk.StringVar()
        channel_id_entry = ctk.CTkEntry(right_panel, textvariable=self.channel_id_var,
                                      placeholder_text="123456789012345678")
        channel_id_entry.grid(row=1, column=0, sticky="ew", pady=(0, 15))

        ctk.CTkLabel(right_panel, text="Message:", font=("", 14, "bold")).grid(
            row=2, column=0, sticky="w", pady=(0, 5))
        self.message_text = ctk.CTkTextbox(right_panel, height=100)
        self.message_text.grid(row=3, column=0, sticky="ew", pady=(0, 15))

        ctk.CTkLabel(right_panel, text="Attachments:", font=("", 14, "bold")).grid(
            row=4, column=0, sticky="w", pady=(0, 5))
        
        self.drop_frame = ctk.CTkFrame(right_panel, height=100, fg_color="#2b2b2b")
        self.drop_frame.grid(row=5, column=0, sticky="ew", pady=(0, 15))
        self.drop_frame.grid_propagate(False)
        
        self.drop_frame.drop_target_register(DND_FILES)
        self.drop_frame.dnd_bind('<<Drop>>', self.on_file_drop)
        
        drop_label = ctk.CTkLabel(self.drop_frame, 
                                 text="📁 Drag & Drop files here\nor click to browse",
                                 text_color="lightblue", font=("", 12))
        drop_label.pack(expand=True)
        drop_label.bind("<Button-1>", self.browse_files)
        self.drop_frame.bind("<Button-1>", self.browse_files)

        self.attachments_list = tk.Listbox(right_panel, height=4, bg="#2b2b2b", 
                                         fg="white", selectbackground="#d9534f")
        self.attachments_list.grid(row=6, column=0, sticky="ew", pady=(0, 15))
        self.attachments_list.bind("<Double-Button-1>", self.remove_attachment)

        button_frame = ctk.CTkFrame(right_panel, fg_color="transparent")
        button_frame.grid(row=7, column=0, sticky="e", pady=(10, 0))
        
        self.delete_btn = ctk.CTkButton(button_frame, text="Delete", 
                                      command=self.delete_channel,
                                      state="disabled", fg_color="#d9534f")
        self.delete_btn.pack(side="right", padx=(10, 0))
        
        self.save_btn = ctk.CTkButton(button_frame, text="Save", 
                                    command=self.save_channel)
        self.save_btn.pack(side="right")

        self.refresh_channel_list()

    def on_file_drop(self, event):
        files = event.data.split()
        for file_path in files:
            file_path = file_path.strip('{}')
            if os.path.exists(file_path):
                self.add_attachment(file_path)

    def browse_files(self, event):
        files = filedialog.askopenfilenames(
            title="Select attachments",
            filetypes=[("All files", "*.*"), 
                      ("Images", "*.png *.jpg *.jpeg *.gif *.bmp"),
                      ("Videos", "*.mp4 *.mov *.avi *.webm")]
        )
        for file_path in files:
            self.add_attachment(file_path)

    def add_attachment(self, file_path):
        if file_path not in self.attachments:
            self.attachments.append(file_path)
            filename = os.path.basename(file_path)
            self.attachments_list.insert(tk.END, filename)

    def remove_attachment(self, event):
        selection = self.attachments_list.curselection()
        if selection:
            index = selection[0]
            self.attachments.pop(index)
            self.attachments_list.delete(index)

    def on_channel_select(self, event):
        selection = self.channel_listbox.curselection()
        if selection:
            index = selection[0]
            channel_id = self.channel_listbox.get(index)
            self.load_channel(channel_id)

    def load_channel(self, channel_id):
        config = self.db.get_config(self.engine.user_id)
        if config and "channels" in config:
            for channel in config["channels"]:
                if channel["id"] == channel_id:
                    self.current_channel = channel
                    self.channel_id_var.set(channel["id"])
                    self.message_text.delete("1.0", "end")
                    self.message_text.insert("1.0", channel.get("message", ""))
                    
                    self.attachments = channel.get("attachments", [])
                    self.attachments_list.delete(0, tk.END)
                    for attachment in self.attachments:
                        filename = os.path.basename(attachment)
                        self.attachments_list.insert(tk.END, filename)
                    
                    self.delete_btn.configure(state="normal")
                    return
        
        self.current_channel = None
        self.channel_id_var.set("")
        self.message_text.delete("1.0", "end")
        self.attachments = []
        self.attachments_list.delete(0, tk.END)
        self.delete_btn.configure(state="disabled")

    def add_channel(self):
        self.current_channel = None
        self.channel_id_var.set("")
        self.message_text.delete("1.0", "end")
        self.attachments = []
        self.attachments_list.delete(0, tk.END)
        self.delete_btn.configure(state="disabled")
        
        self.channel_listbox.insert(tk.END, "New Channel")

    def save_channel(self):
        channel_id = self.channel_id_var.get().strip()
        message = self.message_text.get("1.0", "end-1c").strip()
        
        if not channel_id or not channel_id.isdigit():
            self.show_error("Please enter a valid Channel ID")
            return
        
        channel_data = {
            "id": channel_id,
            "message": message,
            "attachments": self.attachments.copy()
        }
        
        if self.current_channel:
            self.db.update_channel(self.engine.user_id, self.current_channel["id"], channel_data)
        else:
            self.db.add_channel(self.engine.user_id, channel_data)
        
        self.refresh_channel_list()
        self.show_success("Channel saved successfully!")

    def delete_channel(self):
        if self.current_channel:
            self.db.remove_channel(self.engine.user_id, self.current_channel["id"])
            self.refresh_channel_list()
            self.current_channel = None
            self.channel_id_var.set("")
            self.message_text.delete("1.0", "end")
            self.attachments = []
            self.attachments_list.delete(0, tk.END)
            self.delete_btn.configure(state="disabled")
            self.show_info("Channel deleted")

    def refresh_channel_list(self):
        self.channel_listbox.delete(0, tk.END)
        config = self.db.get_config(self.engine.user_id)
        if config and "channels" in config:
            for channel in config["channels"]:
                self.channel_listbox.insert(tk.END, channel["id"])

    def setup_settings_tab(self):
        frame = self.tabview.tab("Settings")
        frame.grid_columnconfigure(0, weight=1)
        
        ctk.CTkLabel(frame, text="Discord Token:", font=("", 14, "bold")).grid(
            row=0, column=0, sticky="w", pady=(10, 5))
        
        self.token_var = ctk.StringVar()
        token_entry = ctk.CTkEntry(frame, textvariable=self.token_var, show="•",
                                 placeholder_text="User token (not bot token)")
        token_entry.grid(row=1, column=0, sticky="ew", pady=(0, 15))

        ctk.CTkLabel(frame, text="Posting Delay (minutes):", font=("", 14, "bold")).grid(
            row=2, column=0, sticky="w", pady=(0, 5))
        
        self.delay_var = ctk.IntVar(value=1)
        delay_slider = ctk.CTkSlider(frame, from_=1, to=60, variable=self.delay_var,
                                   number_of_steps=59)
        delay_slider.grid(row=3, column=0, sticky="ew", pady=(0, 5))
        
        delay_label = ctk.CTkLabel(frame, textvariable=self.delay_var, 
                                 text="1 minute")
        delay_label.grid(row=4, column=0, sticky="w", pady=(0, 15))

        ctk.CTkLabel(frame, text="Webhook URL (optional):", font=("", 14, "bold")).grid(
            row=5, column=0, sticky="w", pady=(0, 5))
        
        self.webhook_var = ctk.StringVar()
        webhook_entry = ctk.CTkEntry(frame, textvariable=self.webhook_var,
                                   placeholder_text="https://discord.com/api/webhooks/...")
        webhook_entry.grid(row=6, column=0, sticky="ew", pady=(0, 15))

        save_btn = ctk.CTkButton(frame, text="Save Settings", 
                               command=self.save_settings, width=120)
        save_btn.grid(row=7, column=0, sticky="e", pady=20)

        self.load_settings()

    def load_settings(self):
        config = self.db.get_config(self.engine.user_id)
        if config:
            self.token_var.set(config.get("token", ""))
            self.delay_var.set(config.get("delay_in_minutes", 1))
            self.webhook_var.set(config.get("webhook_url", ""))

    def save_settings(self):
        settings = {
            "token": self.token_var.get().strip(),
            "delay_in_minutes": self.delay_var.get(),
            "webhook_url": self.webhook_var.get().strip()
        }
        
        if self.db.update_config(self.engine.user_id, settings):
            self.engine.update_config()
            self.show_success("Settings saved successfully!")
        else:
            self.show_error("Failed to save settings")

    def setup_logs_tab(self):
        frame = self.tabview.tab("Logs")
        frame.grid_columnconfigure(0, weight=1)
        frame.grid_rowconfigure(1, weight=1)

        header = ctk.CTkFrame(frame, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", pady=(10, 5))
        
        ctk.CTkLabel(header, text="Logs", font=("", 16, "bold")).pack(side="left")
        
        button_frame = ctk.CTkFrame(header, fg_color="transparent")
        button_frame.pack(side="right")
        
        clear_btn = ctk.CTkButton(button_frame, text="Clear", width=80,
                                command=self.clear_logs)
        clear_btn.pack(side="left", padx=5)
        
        refresh_btn = ctk.CTkButton(button_frame, text="Refresh", width=80,
                                  command=self.refresh_logs)
        refresh_btn.pack(side="left", padx=5)

        self.logs_text = ctk.CTkTextbox(frame, state="disabled", font=("Consolas", 11))
        self.logs_text.grid(row=1, column=0, sticky="nsew", pady=(0, 10))

        self.refresh_logs()

    def refresh_logs(self):
        logs = self.db.get_logs(self.engine.user_id, limit=50)
        self.logs_text.configure(state="normal")
        self.logs_text.delete("1.0", "end")
        
        for log in reversed(logs):
            timestamp = log.get("timestamp", "").strftime("%Y-%m-%d %H:%M:%S") if log.get("timestamp") else "N/A"
            log_type = log.get("type", "info")
            message = log.get("message", "")
            
            if log_type == "error":
                prefix = f"[{timestamp}] ❌ ERROR: "
                color = "red"
            elif log_type == "success":
                prefix = f"[{timestamp}] ✅ SUCCESS: "
                color = "green"
            else:
                prefix = f"[{timestamp}] ℹ️ INFO: "
                color = "lightblue"
            
            self.logs_text.insert("end", prefix, color)
            self.logs_text.insert("end", message + "\n")
        
        self.logs_text.configure(state="disabled")
        self.logs_text.see("end")

    def clear_logs(self):
        if self.db.clear_logs(self.engine.user_id):
            self.refresh_logs()
            self.show_success("Logs cleared successfully!")
        else:
            self.show_error("Failed to clear logs")

    def show_error(self, message):
        print(f"ERROR: {message}")

    def show_success(self, message):
        print(f"SUCCESS: {message}")

    def show_info(self, message):
        print(f"INFO: {message}")

    def start_poster(self):
        def run_engine():
            success = self.engine.start(self.loop)
            if success:
                self.is_running = True
                self.start_time = time.time()
                self.after(0, self._update_ui_on_start)

        thread = threading.Thread(target=run_engine, daemon=True)
        thread.start()

    def stop_poster(self):
        self.engine.stop()
        self.is_running = False
        self._update_ui_on_stop()

    def _update_ui_on_start(self):
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")
        self.status_var.set(f"Status: {self.engine.status}")

    def _update_ui_on_stop(self):
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.status_var.set(f"Status: {self.engine.status}")

    def update_status(self):
        if self.is_running and self.start_time:
            uptime_seconds = int(time.time() - self.start_time)
            hours = uptime_seconds // 3600
            minutes = (uptime_seconds % 3600) // 60
            seconds = uptime_seconds % 60
            self.uptime_var.set(f"Uptime: {hours:02d}:{minutes:02d}:{seconds:02d}")
        
        self.status_var.set(f"Status: {self.engine.status}")
        self.after(1000, self.update_status)