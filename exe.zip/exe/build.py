import PyInstaller.__main__
import os

PyInstaller.__main__.run([
    'main.py',
    '--name=AutoPosterPro',
    '--onefile',
    '--windowed',
    '--icon=assets/icon.ico',
    '--add-data=assets;assets',
    '--additional-hooks-dir=hooks',
    '--clean',
    '--noconfirm'
])